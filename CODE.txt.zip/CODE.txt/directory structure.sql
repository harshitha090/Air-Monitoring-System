project_folder/
│
├── app.py
├── data_processing.py
├── static/
│   └── generated_art/
│       └── generated_art_<timestamp>.png
├── templates/
│   ├── index.html
│   └── visualization.html
├── requirements.txt
├── Procfile
└── ...
