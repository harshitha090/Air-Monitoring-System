from flask import Flask, jsonify, render_template
import pandas as pd
from data_processing import preprocess_data, load_data

app = Flask(__name__)

@app.route('/')
def index():
    return render_template("index.html")

@app.route('/api/environmental_data', methods=['GET'])
def get_environmental_data():
    # Load and preprocess data
    df = load_data()
    processed_df = preprocess_data(df)
    data = processed_df.to_dict(orient="records")
    return jsonify(data)

if __name__ == "__main__":
    app.run(debug=True)
