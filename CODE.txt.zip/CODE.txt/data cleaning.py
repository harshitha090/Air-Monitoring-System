import pandas as pd
import numpy as np

# Load the data for processing
def load_data(filename="environmental_data.csv"):
    return pd.read_csv(filename)

# Clean and prepare data
def preprocess_data(df):
    # Drop unnecessary columns if any
    df = df.dropna()  # Drop rows with any missing values
    df['air_quality_index'] = df['main.aqi']  # Use AQI for simplicity
    return df[['timestamp', 'air_quality_index']]

# Example usage
if __name__ == "__main__":
    df = load_data()
    processed_df = preprocess_data(df)
    print(processed_df.head())
