import plotly.express as px
import pandas as pd

def visualize_data():
    df = pd.read_csv("environmental_data.csv")
    fig = px.line(df, x='timestamp', y='air_quality_index', title="Air Quality Over Time")
    fig.write_html("templates/visualization.html")

if __name__ == "__main__":
    visualize_data()
