import os
from datetime import datetime
from diffusers import StableDiffusionPipeline
import torch
import pandas as pd

# Initialize Stable Diffusion model
pipeline = StableDiffusionPipeline.from_pretrained("CompVis/stable-diffusion-v1-4", torch_dtype=torch.float16)
pipeline = pipeline.to("cuda")

# Directory for saving generated art
ART_DIR = "static/generated_art"

# Ensure the directory exists
os.makedirs(ART_DIR, exist_ok=True)

# Function to generate art based on data
def generate_art(data):
    prompt = f"Create an art piece based on air quality index {data['air_quality_index']}."
    image = pipeline(prompt).images[0]
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    image_path = f"{ART_DIR}/generated_art_{timestamp}.png"
    image.save(image_path)
    return image_path  # Return path to use in the web app

# Generate art for the latest data
if __name__ == "__main__":
    df = pd.read_csv("environmental_data.csv")
    latest_data = df.iloc[-1]  # Get the latest data entry
    art_path = generate_art(latest_data)
    print(f"Art generated and saved at: {art_path}")
