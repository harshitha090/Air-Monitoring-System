import requests
import pandas as pd
import os
from datetime import datetime

# API Key and endpoint configuration
API_KEY = os.getenv("API_KEY")  # Place your API key here
BASE_URL = "http://api.openweathermap.org/data/2.5/air_pollution"

# Function to fetch environmental data
def fetch_environmental_data(city="YourCity"):
    params = {
        'q': city,
        'appid': API_KEY
    }
    response = requests.get(BASE_URL, params=params)
    if response.status_code == 200:
        data = response.json()
        # Convert to DataFrame for processing
        df = pd.json_normalize(data, 'list')
        df['timestamp'] = datetime.now()
        return df
    else:
        print(f"Failed to retrieve data. Status code: {response.status_code}")
        return None

# Example of saving data to a CSV file
def save_data(df, filename="environmental_data.csv"):
    df.to_csv(filename, mode='a', header=not os.path.exists(filename), index=False)

# Main function to run data collection and saving
if __name__ == "__main__":
    data = fetch_environmental_data()
    if data is not None:
        save_data(data)
